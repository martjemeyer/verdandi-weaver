/* Verdandi — theme toggle + tweaks + scroll-in animations */
(function () {
  const root = document.documentElement;

  // ---- Theme ----
  const stored = localStorage.getItem("vw-theme");
  const stored_pal = localStorage.getItem("vw-palette");
  const stored_font = localStorage.getItem("vw-font");
  if (stored) root.setAttribute("data-theme", stored);
  else if (window.matchMedia("(prefers-color-scheme: dark)").matches) root.setAttribute("data-theme", "dark");
  if (stored_pal) root.setAttribute("data-palette", stored_pal);
  if (stored_font) root.setAttribute("data-font", stored_font);

  function setTheme(mode) {
    if (mode === "light") root.removeAttribute("data-theme");
    else root.setAttribute("data-theme", "dark");
    localStorage.setItem("vw-theme", mode);
  }
  document.addEventListener("click", (e) => {
    const t = e.target.closest("[data-theme-toggle]");
    if (!t) return;
    const cur = root.getAttribute("data-theme") === "dark" ? "dark" : "light";
    setTheme(cur === "dark" ? "light" : "dark");
  });

  // ---- Mobile nav ----
  document.addEventListener("click", (e) => {
    const t = e.target.closest("[data-nav-toggle]");
    if (!t) return;
    t.closest(".nav").classList.toggle("is-open");
  });

  // ---- Fade-up on scroll ----
  // Only arm the hidden initial state if the document is actually visible and
  // the timeline will progress. Otherwise content stays visible by default so
  // a paused preview never traps it at opacity 0.
  const canFade = document.visibilityState === "visible" &&
    !window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  if (canFade) {
    root.classList.add("fade-armed");
    const io = new IntersectionObserver(
      (entries) => entries.forEach((en) => en.isIntersecting && en.target.classList.add("is-in")),
      { threshold: 0.08 }
    );
    document.querySelectorAll(".fade-up").forEach((el) => io.observe(el));
  }

  // ---- Tweaks ----
  const tweaks = document.querySelector("[data-tweaks]");
  function applyPalette(p) {
    if (p === "warm") root.removeAttribute("data-palette");
    else root.setAttribute("data-palette", p);
    localStorage.setItem("vw-palette", p);
  }
  function applyFont(f) {
    root.setAttribute("data-font", f);
    if (f === "modern") {
      root.style.setProperty("--font-display", '"Fraunces", Georgia, serif');
      root.style.setProperty("--font-body", '"Inter", system-ui, sans-serif');
    } else if (f === "humanist") {
      root.style.setProperty("--font-display", '"EB Garamond", Georgia, serif');
      root.style.setProperty("--font-body", '"Work Sans", system-ui, sans-serif');
    } else {
      root.style.removeProperty("--font-display");
      root.style.removeProperty("--font-body");
    }
    localStorage.setItem("vw-font", f);
  }

  // Reflect stored values in chip aria-pressed
  function syncChips() {
    if (!tweaks) return;
    tweaks.querySelectorAll("[data-set]").forEach((b) => {
      const [k, v] = b.dataset.set.split(":");
      const cur =
        k === "palette" ? (root.getAttribute("data-palette") || "warm") :
        k === "font" ? (root.getAttribute("data-font") || "classic") :
        k === "theme" ? (root.getAttribute("data-theme") === "dark" ? "dark" : "light") : null;
      b.setAttribute("aria-pressed", String(cur === v));
    });
  }
  syncChips();

  if (tweaks) {
    tweaks.addEventListener("click", (e) => {
      const b = e.target.closest("[data-set]");
      if (!b) return;
      const [k, v] = b.dataset.set.split(":");
      if (k === "palette") applyPalette(v);
      if (k === "font") applyFont(v);
      if (k === "theme") setTheme(v);
      syncChips();
    });
    tweaks.querySelector("[data-tweaks-close]").addEventListener("click", () => tweaks.classList.remove("is-open"));
  }
  document.addEventListener("click", (e) => {
    if (e.target.closest("[data-tweaks-open]")) tweaks?.classList.add("is-open");
  });
})();
